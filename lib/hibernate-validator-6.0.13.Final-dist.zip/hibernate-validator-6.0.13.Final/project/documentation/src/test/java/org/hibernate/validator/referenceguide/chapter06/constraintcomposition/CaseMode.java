package org.hibernate.validator.referenceguide.chapter06.constraintcomposition;

public enum CaseMode {
	UPPER,
	LOWER;
}
